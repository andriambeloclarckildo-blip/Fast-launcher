package com.ildo.fastlauncher

import android.content.ComponentName
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

data class AppEntry(val label: String, val pkg: String, val component: ComponentName, val icon: Bitmap)

class AppAdapter(
    private val onClick: (AppEntry) -> Unit,
    private val onLong: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppEntry> = emptyList()

    class VH(v: android.view.View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    fun submit(list: List<AppEntry>) {
        val old = items
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = list.size
            override fun areItemsTheSame(a: Int, b: Int) = old[a].component == list[b].component
            override fun areContentsTheSame(a: Int, b: Int) = old[a] == list[b]
        })
        items = list
        diff.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val v = LayoutInflater.from(p.context).inflate(R.layout.item_app, p, false)
        val vh = VH(v)
        v.setOnClickListener { vh.bindingAdapterPosition.takeIf { it >= 0 }?.let { onClick(items[it]) } }
        v.setOnLongClickListener { vh.bindingAdapterPosition.takeIf { it >= 0 }?.let { onLong(items[it]) }; true }
        return vh
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        h.icon.setImageBitmap(items[i].icon)
        h.label.text = items[i].label
    }

    override fun getItemCount() = items.size
}
