package com.ildo.fastlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var drawer: View
    private lateinit var search: EditText
    private lateinit var adapter: AppAdapter
    private val io = Executors.newSingleThreadExecutor()
    private var all: List<AppEntry> = emptyList()
    private var drawerOpen = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = loadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom)
            insets
        }

        drawer = findViewById(R.id.drawer)
        search = findViewById(R.id.search)

        adapter = AppAdapter(::launch) { openAppInfo(it) }
        findViewById<RecyclerView>(R.id.apps).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = this@MainActivity.adapter
            setHasFixedSize(true)
            setItemViewCacheSize(24)
            itemAnimator = null
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = applyFilter()
        })

        // Swipe up = open drawer, long press = wallpaper
        val dp = resources.displayMetrics.density
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && e1.y - e2.y > 80 * dp && vy < -600) { openDrawer(); return true }
                return false
            }
            override fun onLongPress(e: MotionEvent) {
                runCatching { startActivity(Intent(Intent.ACTION_SET_WALLPAPER)) }
            }
        })
        findViewById<View>(R.id.home).setOnTouchListener { _, e -> gd.onTouchEvent(e) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (drawerOpen) closeDrawer() }
        })

        setupDock()
        loadApps()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && drawerOpen) closeDrawer()
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        io.shutdown()
        super.onDestroy()
    }

    private fun setupDock() {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val ids = listOf(R.id.dock0, R.id.dock1, R.id.dock2, R.id.dock3)
        intents.forEachIndexed { i, intent ->
            val iv = findViewById<ImageView>(ids[i])
            val ri = packageManager.resolveActivity(intent, 0) ?: return@forEachIndexed
            iv.setImageDrawable(ri.loadIcon(packageManager))
            iv.setOnClickListener { runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
        }
    }

    private fun loadApps() {
        val size = (resources.displayMetrics.density * 56).toInt().coerceAtLeast(96)
        io.execute {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppEntry(
                        it.loadLabel(pm).toString(), it.activityInfo.packageName,
                        android.content.ComponentName(it.activityInfo.packageName, it.activityInfo.name),
                        it.loadIcon(pm).toBitmap(size, size)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread { all = list; applyFilter() }
        }
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        adapter.submit(if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) })
    }

    private fun launch(a: AppEntry) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(a.component).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        runCatching { startActivity(i) }
        closeDrawer()
    }

    private fun openAppInfo(a: AppEntry) {
        runCatching {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
        }
    }

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        drawer.translationY = drawer.height.toFloat().coerceAtLeast(1500f)
        drawer.animate().translationY(0f).setDuration(240)
            .setInterpolator(DecelerateInterpolator(1.5f)).withLayer().start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        drawer.animate().translationY(drawer.height.toFloat()).setDuration(200)
            .setInterpolator(DecelerateInterpolator()).withLayer()
            .withEndAction { drawer.visibility = View.GONE; search.setText("") }.start()
    }
}
